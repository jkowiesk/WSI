class Move:
    """A base class for classes that represent moves in games"""
    pass
